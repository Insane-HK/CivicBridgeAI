# How We Built CivicBridge AI

*(Technical Blog Post tailored for Dev platforms like Hashnode/Dev.to)*

## The Problem Space
We noticed a profound disconnect between government aid availability and citizen awareness. The primary bottleneck? PDFs. Bureaucratic criteria locked in unstructured text files prevent automated matching. We needed to turn unstructured semantic text into structured, queryable data.

## Architecture Overview
We opted for a Serverless first approach using AWS Lambda, API Gateway, and DynamoDB. 

Our 'secret sauce' lives in the `ProcessScheme` Lambda function. When a PDF hits our S3 bucket, this Lambda sends the document text to **Amazon Bedrock (Nova model)**. We aggressively prompt the LLM to return strict JSON containing variables like `min_age` or `eligible_genders`.

![Architecture Diagram](../media_assets/architecture_diagram.png)

## Development Journey & Challenges
One of the biggest hurdles was AWS permissions and configuration. We fought through strict Windows OpenSSH permission issues when trying to SCP our built React frontend onto our newly provisioned EC2 instance. 

**The Fix:** We wrote a custom Python deployment script utilizing `paramiko` to bypass native SSH OS lockdowns, automatically packaging our Vite build and restarting Nginx in a sequence. 

## Lessons Learned
- LLM outputs need strict guarding. Asking Bedrock for schemas requires heavy system prompting.
- EC2 default permissions require double-checking when automating file transfers.

## Future Improvements
Next, we want to expand the AI to support direct WhatsApp API integration, completely removing the need for a web-app for our lowest-literacy users.
